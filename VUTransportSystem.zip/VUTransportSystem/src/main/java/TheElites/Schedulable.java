
package TheElites;


public interface Schedulable {
      void scheduleService();
    
}
