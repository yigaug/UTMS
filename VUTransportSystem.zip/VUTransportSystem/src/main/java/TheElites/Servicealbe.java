
package TheElites;

public interface Servicealbe {
    void makeService();
    
}
