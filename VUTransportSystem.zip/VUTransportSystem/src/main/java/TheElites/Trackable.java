
package TheElites;

public interface Trackable {
  void trackvehicle();
    
}
